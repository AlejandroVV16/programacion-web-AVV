import random
import numpy as np

def contar_movimientos_reina(tamaño_tablero=8, pos_reina=None, posiciones_piedras=None):
    """
    Simula un tablero de ajedrez con una reina y múltiples piedras.
    Cuenta cuántos movimientos válidos puede hacer la reina sin ser bloqueada por las piedras.
    
    Args:
        tamaño_tablero (int): Tamaño del tablero (por defecto 8x8)
        pos_reina (tuple): Posición de la reina (fila, columna)
        posiciones_piedras (list): Lista de posiciones de las piedras [(fila, columna), ...]
    
    Returns:
        dict: Diccionario con información del resultado
    """
    
    # Crear tablero vacío
    tablero = np.zeros((tamaño_tablero, tamaño_tablero), dtype=int)
    
    # Si no se proporcionan posiciones, generarlas aleatoriamente
    if pos_reina is None or posiciones_piedras is None:
        # Generar posiciones aleatorias para reina y una piedra
        posiciones = random.sample(range(tamaño_tablero * tamaño_tablero), 2)
        if pos_reina is None:
            pos_reina = (posiciones[0] // tamaño_tablero, posiciones[0] % tamaño_tablero)
        if posiciones_piedras is None:
            posiciones_piedras = [(posiciones[1] // tamaño_tablero, posiciones[1] % tamaño_tablero)]
    
    # Marcar posiciones en el tablero (1=reina, 2=piedra)
    tablero[pos_reina] = 1
    for pos_piedra in posiciones_piedras:
        tablero[pos_piedra] = 2
    
    # Direcciones de movimiento de la reina (8 direcciones)
    direcciones = [
        (-1, -1), (-1, 0), (-1, 1),  # diagonal superior, vertical arriba, diagonal superior
        (0, -1),           (0, 1),   # horizontal izquierda, horizontal derecha
        (1, -1),  (1, 0),  (1, 1)    # diagonal inferior, vertical abajo, diagonal inferior
    ]
    
    movimientos_validos = []
    
    # Para cada dirección, contar movimientos hasta encontrar obstáculo o borde
    for dx, dy in direcciones:
        fila, col = pos_reina
        movimientos_en_direccion = []
        
        while True:
            # Calcular siguiente posición
            nueva_fila = fila + dx
            nueva_col = col + dy
            
            # Verificar si está dentro del tablero
            if (nueva_fila < 0 or nueva_fila >= tamaño_tablero or 
                nueva_col < 0 or nueva_col >= tamaño_tablero):
                break
                
            # Verificar si hay una piedra en esta posición
            if (nueva_fila, nueva_col) in posiciones_piedras:
                break
                
            # Si llegamos aquí, es un movimiento válido
            movimientos_en_direccion.append((nueva_fila, nueva_col))
            fila, col = nueva_fila, nueva_col
        
        movimientos_validos.extend(movimientos_en_direccion)
    
    return {
        'tablero': tablero,
        'pos_reina': pos_reina,
        'posiciones_piedras': posiciones_piedras,
        'movimientos_validos': movimientos_validos,
        'total_movimientos': len(movimientos_validos)
    }

def mostrar_tablero(resultado):
    """
    Muestra el tablero de forma visual con la reina, piedra y movimientos posibles.
    """
    tablero = resultado['tablero'].copy()
    movimientos = resultado['movimientos_validos']
    
    # Marcar movimientos posibles con 3
    for mov in movimientos:
        tablero[mov] = 3
    
    # Restaurar posiciones originales
    tablero[resultado['pos_reina']] = 1
    for pos_piedra in resultado['posiciones_piedras']:
        tablero[pos_piedra] = 2
    
    print("Tablero:")
    print("R = Reina, P = Piedra, · = Movimiento posible, □ = Vacío")
    print()
    
    simbolos = {0: '□', 1: 'R', 2: 'P', 3: '·'}
    
    for fila in tablero:
        print(' '.join(simbolos[celda] for celda in fila))
    print()

def simular_multiples_partidas(num_simulaciones=1000, tamaño_tablero=8):
    """
    Ejecuta múltiples simulaciones y calcula estadísticas.
    """
    resultados = []
    
    for _ in range(num_simulaciones):
        resultado = contar_movimientos_reina(tamaño_tablero)
        resultados.append(resultado['total_movimientos'])
    
    return {
        'promedio': np.mean(resultados),
        'minimo': min(resultados),
        'maximo': max(resultados),
        'desviacion_estandar': np.std(resultados),
        'simulaciones': resultados
    }

def obtener_input_usuario():
    """
    Obtiene inputs del usuario para configurar el juego.
    """
    # Obtener tamaño del tablero
    while True:
        try:
            tamaño = int(input("Ingrese el tamaño del tablero (ej: 8 para 8x8): "))
            if tamaño > 1:
                break
            else:
                print("El tamaño debe ser mayor a 1.")
        except ValueError:
            print("Por favor ingrese un número válido.")
    
    print(f"\nTablero de {tamaño}x{tamaño}")
    print("Las posiciones van de 0 a", tamaño-1)
    
    # Obtener posición de la reina
    while True:
        try:
            fila_reina = int(input(f"Ingrese la fila de la reina (0-{tamaño-1}): "))
            col_reina = int(input(f"Ingrese la columna de la reina (0-{tamaño-1}): "))
            
            if 0 <= fila_reina < tamaño and 0 <= col_reina < tamaño:
                pos_reina = (fila_reina, col_reina)
                break
            else:
                print(f"Las posiciones deben estar entre 0 y {tamaño-1}")
        except ValueError:
            print("Por favor ingrese números válidos.")
    
    # Obtener número de piedras
    max_piedras = (tamaño * tamaño) - 1  # -1 porque la reina ocupa una posición
    while True:
        try:
            num_piedras = int(input(f"¿Cuántas piedras desea colocar? (1-{max_piedras}): "))
            if 1 <= num_piedras <= max_piedras:
                break
            else:
                print(f"El número de piedras debe estar entre 1 y {max_piedras}")
        except ValueError:
            print("Por favor ingrese un número válido.")
    
    # Obtener posiciones de las piedras
    posiciones_piedras = []
    posiciones_ocupadas = {pos_reina}  # Conjunto con la posición de la reina
    
    for i in range(num_piedras):
        while True:
            try:
                print(f"\nPiedra {i+1}:")
                fila_piedra = int(input(f"Ingrese la fila de la piedra {i+1} (0-{tamaño-1}): "))
                col_piedra = int(input(f"Ingrese la columna de la piedra {i+1} (0-{tamaño-1}): "))
                
                pos_piedra = (fila_piedra, col_piedra)
                
                # Verificar que esté dentro del tablero
                if not (0 <= fila_piedra < tamaño and 0 <= col_piedra < tamaño):
                    print(f"Las posiciones deben estar entre 0 y {tamaño-1}")
                    continue
                
                # Verificar que no esté ocupada
                if pos_piedra in posiciones_ocupadas:
                    if pos_piedra == pos_reina:
                        print("Esta posición está ocupada por la reina.")
                    else:
                        print("Esta posición ya está ocupada por otra piedra.")
                    continue
                
                # Si llegamos aquí, la posición es válida
                posiciones_piedras.append(pos_piedra)
                posiciones_ocupadas.add(pos_piedra)
                break
                
            except ValueError:
                print("Por favor ingrese números válidos.")
    
    return tamaño, pos_reina, posiciones_piedras

# Ejemplo de uso
if __name__ == "__main__":
    print("=== SIMULADOR DE MOVIMIENTOS DE REINA ===")
    
    # Obtener configuración del usuario
    tamaño, pos_reina, posiciones_piedras = obtener_input_usuario()
    
    print("\n=== SIMULACIÓN CON TUS CONFIGURACIONES ===")
    resultado = contar_movimientos_reina(tamaño, pos_reina, posiciones_piedras)
    
    print(f"Posición de la reina: {resultado['pos_reina']}")
    print(f"Posiciones de las piedras: {resultado['posiciones_piedras']}")
    print(f"Número total de piedras: {len(resultado['posiciones_piedras'])}")
    print(f"Total de movimientos posibles: {resultado['total_movimientos']}")
    print()
    
    mostrar_tablero(resultado)